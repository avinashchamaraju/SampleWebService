package com.agiliisum.webservice.productdetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.agiliisum.webservice.productdetails.domain.ProductDetails;
import com.agiliisum.webservice.productdetails.exception.ProductNotFoundException;
import com.agiliisum.webservice.productdetails.service.ProductDetailsService;

@RestController
public class ProductController {
	
	
	 @Autowired  
	 ProductDetailsService service;
	 
	
	@GetMapping(path="/productDetails")
	public List<ProductDetails> getProductDetails()
	{
		return service.getProductDetails();
	}
	
	@GetMapping(path="/productDetails/{id}")
	public ProductDetails getProduct(@PathVariable int id)
	{
		ProductDetails  productDetails = service.getProductDetail(id);
		if(productDetails == null)
		{
			throw new ProductNotFoundException("id = "+id);
		}
		return  productDetails;
	}
	
	@PostMapping(path="/productDetails")
	public List<ProductDetails> addProduct(@RequestBody ProductDetails productDetails)
	{
		return service.addProduct(productDetails);
	}
	
	@DeleteMapping(path="/productDetails/{id}")
	public ProductDetails deleteProduct(@PathVariable int id){
		return service.deleteProduct(id);
	}
	
}
