package com.agiliisum.webservice.productdetails.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

import com.agiliisum.webservice.productdetails.domain.ProductDetails;

@Component
public class ProductDetailsService {

	private static List<ProductDetails> productDetailsList = new ArrayList<ProductDetails>();

	private static int count = 3;

	static {
		productDetailsList.add(new ProductDetails(1, "bisket", 10));
		productDetailsList.add(new ProductDetails(2, "chocklate", 20));
		productDetailsList.add(new ProductDetails(3, "cake", 15));
	}

	public List<ProductDetails> getProductDetails() {
		return productDetailsList;
	}

	public ProductDetails getProductDetail(int id) {
		for (ProductDetails productDetail : productDetailsList)
			if (id == productDetail.getId()) {
				return productDetail;
			}
		return null;
	}

	public List<ProductDetails> addProduct(ProductDetails productDetails) {
		if (Integer.valueOf(productDetails.getId()) == null) {
			productDetails.setId(++count);
		}
		productDetailsList.add(productDetails);
		return productDetailsList;
	}

	public ProductDetails deleteProduct(int id) {
		Iterator<ProductDetails> it = productDetailsList.iterator();
		while (it.hasNext()) {
			ProductDetails productDetails = it.next();
			if (productDetails.getId() == id) {
				it.remove();
				return productDetails;
			}
		}
		return null;
	}
}
